from distutils.core import setup

setup(
    name = 'learn_list',
    version = '1.3.0',
    py_modules = ['learn_list'],
    author = 'Fallin',
    author_email = "69426612@qq.com",
    url = "",
    description = "this is the test of learning py",
)