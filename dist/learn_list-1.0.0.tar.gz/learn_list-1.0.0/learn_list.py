# 对list的渐进使用
"""据说这样
可以使用多行注释
"""
movies = ["the holy gails", 1975, "terry jones", ["gtaham", ["eric idle"]]]
for each_name in movies:
    print(each_name)

# count = 0
# while count < len(movies):
#     print(movies[count])
#     count = count + 1
# movies.append("a")
# print(movies)

for each_name in movies:
    if isinstance(each_name, list):
        for each_item in each_name:
            print(each_item)
    else:
        print(each_name)

def deal_with_list (the_list):
    for each_item in the_list:
        if isinstance(each_item, list):
            deal_with_list(each_item)
        else:
            print(each_item)


deal_with_list(movies)